"use client";
import axios from "axios";
import { useEffect, useState } from "react";

export default function MCX() {
  const [mcx, setMcx] = useState([]);

  useEffect(() => {
    const load = async () => {
      setMcx((await axios.get("http://localhost:5000/api/live/mcx")).data);
    };
    load();
    const id = setInterval(load, 2000);
    return () => clearInterval(id);
  }, []);

  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">MCX Live</h1>
      <table className="w-full bg-white shadow rounded">
        <thead>
          <tr className="bg-gray-100">
            <th className="p-2">Symbol</th>
            <th className="p-2">LTP</th>
            <th className="p-2">Change</th>
          </tr>
        </thead>
        <tbody>
          {mcx.map((d, i) => (
            <tr key={i} className="border-b">
              <td className="p-2">{d.symbol}</td>
              <td className="p-2">{d.ltp}</td>
              <td className={d.change>0?"p-2 text-green-600":"p-2 text-red-600"}>
                {d.change}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}