"use client";
import axios from "axios";
import { useEffect, useState } from "react";
import OptionChainTable from "../../components/OptionChainTable";

export default function OC() {
  const [chain, setChain] = useState([]);

  useEffect(() => {
    const load = async () => {
      setChain((await axios.get("http://localhost:5000/api/live/option-chain")).data);
    };
    load();
    const id = setInterval(load, 2500);
    return () => clearInterval(id);
  }, []);

  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Option Chain</h1>
      <OptionChainTable data={chain} />
    </div>
  );
}