"use client";
import axios from "axios";
import { useEffect, useState } from "react";
import Card from "../components/Card";
import LiveTable from "../components/LiveTable";

export default function Home() {
  const [nifty, setNifty] = useState({});
  const [banknifty, setBanknifty] = useState({});
  const [mcx, setMcx] = useState([]);

  useEffect(() => {
    const load = async () => {
      let index = await axios.get("http://localhost:5000/api/live/index");
      let mcxData = await axios.get("http://localhost:5000/api/live/mcx");
      setNifty(index.data.nifty);
      setBanknifty(index.data.banknifty);
      setMcx(mcxData.data);
    };
    load();
    const id = setInterval(load, 2000);
    return () => clearInterval(id);
  }, []);

  return (
    <div>
      <h1 className="text-3xl font-bold mb-4">Market Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card title="Nifty 50" value={nifty.ltp} change={nifty.change} />
        <Card title="BankNifty" value={banknifty.ltp} change={banknifty.change} />
        <Card title="Gold (MCX)" value={mcx[0]?.ltp} change={mcx[0]?.change} />
      </div>
      <h2 className="text-xl font-bold mt-6 mb-2">MCX Live Rates</h2>
      <LiveTable data={mcx} />
    </div>
  );
}