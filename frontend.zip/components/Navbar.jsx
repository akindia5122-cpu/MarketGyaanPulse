export default function Navbar() {
  return (
    <nav className="bg-white shadow p-4 flex justify-between">
      <h1 className="text-2xl font-bold text-blue-600">Market Gyaan Pulse</h1>
      <div className="flex gap-6">
        <a href="/">Home</a>
        <a href="/mcx">MCX</a>
        <a href="/option-chain">Option Chain</a>
      </div>
    </nav>
  );
}