export default function Card({ title, value, change }) {
  return (
    <div className="bg-white shadow rounded p-4">
      <h2 className="text-lg">{title}</h2>
      <p className="text-3xl font-bold">{value}</p>
      <p className={change>0?"text-green-600":"text-red-600"}>{change}</p>
    </div>
  );
}