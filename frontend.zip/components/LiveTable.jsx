export default function LiveTable({ data }) {
  return (
    <table className="w-full bg-white shadow rounded">
      <thead>
        <tr className="bg-gray-100">
          <th className="p-2">Symbol</th>
          <th className="p-2">LTP</th>
          <th className="p-2">Change</th>
        </tr>
      </thead>
      <tbody>
        {data.map((d,i)=>(
          <tr key={i} className="border-b">
            <td className="p-2">{d.symbol}</td>
            <td className="p-2">{d.ltp}</td>
            <td className={d.change>0?"p-2 text-green-600":"p-2 text-red-600"}>
              {d.change}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}