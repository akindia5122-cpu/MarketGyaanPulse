export default function OptionChainTable({ data }) {
  return (
    <table className="w-full bg-white shadow rounded">
      <thead>
        <tr className="bg-gray-100">
          <th className="p-2">CE OI</th>
          <th className="p-2">CE LTP</th>
          <th className="p-2">STRIKE</th>
          <th className="p-2">PE LTP</th>
          <th className="p-2">PE OI</th>
        </tr>
      </thead>

      <tbody>
        {data.map((item, i) => (
          <tr key={i} className="border-b">
            <td className="p-2">{item.CE.oi}</td>
            <td className="p-2">{item.CE.ltp}</td>
            <td className="p-2 font-bold bg-gray-50">{item.strike}</td>
            <td className="p-2">{item.PE.ltp}</td>
            <td className="p-2">{item.PE.oi}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}