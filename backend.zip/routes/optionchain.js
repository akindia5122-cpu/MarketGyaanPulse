const router = require("express").Router();

router.get("/option-chain", (req, res) => {
  res.json([
    {
      strike: 22000,
      CE: { ltp: 120, oi: 35500 },
      PE: { ltp: 140, oi: 42000 }
    },
    {
      strike: 22100,
      CE: { ltp: 90, oi: 29500 },
      PE: { ltp: 165, oi: 38000 }
    }
  ]);
});

module.exports = router;