const router = require("express").Router();

router.get("/index", (req, res) => {
  res.json({
    nifty: { ltp: 22200, change: -45 },
    banknifty: { ltp: 48200, change: +120 }
  });
});

router.get("/mcx", (req, res) => {
  res.json([
    { symbol: "GOLD", ltp: 62200, high: 62400, low: 62000, change: -80 },
    { symbol: "CRUDEOIL", ltp: 6650, high: 6700, low: 6600, change: +15 }
  ]);
});

module.exports = router;